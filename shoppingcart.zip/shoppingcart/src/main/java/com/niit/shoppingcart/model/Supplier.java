package com.niit.shoppingcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Supplier
{
		@Id
		private String sid;
		private String sname;
		private String sphonenumber;
		private String saddress;

		public String getsid() 
		{
			return sid;
		}
		public void setsid(String sid)
		{
			this.sid = sid;
		}
		public String getsname()
		{
			return sname;
		}
		public void setsname(String sname) 
		{
			this.sname = sname;
		}
		public String getsphonenumber()
		{
			return sphonenumber;
		}
		public void setsphonenumber(String sphonenumber)
		{
			this.sphonenumber = sphonenumber;
		}
		public String getsaddress()
		{
			return saddress;
		}
		public void setsaddress(String saddress) {
			this.saddress = saddress;
		}
	
}
